# Collab Platform Frontend

Anonymous real-time collaboration platform frontend built with React and Vite.

## Features

- **Clean React Components** with functional design
- **Real-time Socket.io** connection
- **Text and Code Messages** with syntax highlighting
- **Responsive Design** for mobile and desktop
- **Auto-scroll Chat** window
- **Rate Limiting** feedback
- **Connection Status** indicators

## Installation

```bash
npm install
```

## Run

```bash
# Development server (with hot reload)
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

Development server runs on port 5173.

## Project Structure

```
frontend/
├── src/
│   ├── components/
│   │   ├── HomePage.jsx         # Landing page
│   │   ├── HomePage.css
│   │   ├── RoomPage.jsx         # Main room interface
│   │   ├── RoomPage.css
│   │   ├── ChatWindow.jsx       # Message display
│   │   ├── ChatWindow.css
│   │   ├── Message.jsx          # Individual message
│   │   ├── Message.css
│   │   ├── InputBox.jsx         # Message input
│   │   └── InputBox.css
│   ├── App.jsx                  # Main app component
│   ├── App.css
│   ├── main.jsx                 # Entry point
│   └── index.css                # Global styles
├── index.html
├── vite.config.js
└── package.json
```

## Component Architecture

```
App
 ├── HomePage (nickname + room code input)
 └── RoomPage (room interface)
      ├── ChatWindow (message display)
      │    └── Message (individual message)
      └── InputBox (message input)
```

## Usage

1. Enter nickname on home page
2. Create new room or join existing with 6-char code
3. Send text messages normally
4. Use `/code ` prefix for code snippets
5. Press Enter to send, Shift+Enter for new line

## Backend Connection

Configure backend URL in `RoomPage.jsx`:
```javascript
const SOCKET_URL = 'http://localhost:3000';
```
