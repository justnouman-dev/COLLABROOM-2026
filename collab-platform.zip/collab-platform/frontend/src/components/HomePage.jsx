import { useState } from 'react';
import './HomePage.css';

/**
 * HomePage Component
 * Landing page with nickname input and room creation/joining
 */
function HomePage({ onJoinRoom }) {
  const [nickname, setNickname] = useState('');
  const [roomCode, setRoomCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  /**
   * Generate a random 6-character room code
   */
  const generateRoomCode = () => {
  // Generate random 5-digit number
  const randomNum = Math.floor(Math.random() * 100000);
  return randomNum.toString().padStart(5, '0');
};

  /**
   * Validate inputs
   */
  const validateInputs = (nick, code) => {
    if (!nick.trim()) {
      setError('Please enter a nickname');
      return false;
    }

    if (nick.length > 20) {
      setError('Nickname must be 20 characters or less');
      return false;
    }

    if (code && !/^\d{5}$/.test(code)) {
  setError('Room code must be exactly 5 digits');
  return false;
}

    return true;
  };

  /**
   * Handle creating a new room
   */
  const handleCreateRoom = () => {
    setError('');
    
    if (!validateInputs(nickname, '')) {
      return;
    }

    setLoading(true);
    const newRoomCode = generateRoomCode();
    
    // Simulate brief loading
    setTimeout(() => {
      setLoading(false);
      onJoinRoom(newRoomCode, nickname.trim());
    }, 300);
  };

  /**
   * Handle joining an existing room
   */
  const handleJoinRoom = () => {
    setError('');
    
    if (!validateInputs(nickname, roomCode)) {
      return;
    }

    setLoading(true);
    
    // Simulate brief loading
    setTimeout(() => {
      setLoading(false);
      onJoinRoom(roomCode.toUpperCase(), nickname.trim());
    }, 300);
  };

  /**
   * Handle Enter key press
   */
  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !loading) {
      if (roomCode) {
        handleJoinRoom();
      } else {
        handleCreateRoom();
      }
    }
  };

  return (
    <div className="home-page">
      <div className="home-container">
        <div className="home-header">
          <h1 className="home-title">🚀 Collab Platform</h1>
          <p className="home-subtitle">Anonymous Real-time Collaboration</p>
        </div>

        <div className="home-form">
          {error && (
            <div className="error-message">
              ⚠️ {error}
            </div>
          )}

          <div className="input-group">
            <label htmlFor="nickname">Nickname</label>
            <input
              id="nickname"
              type="text"
              placeholder="Enter your nickname"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              onKeyPress={handleKeyPress}
              maxLength={20}
              disabled={loading}
              autoFocus
            />
            <span className="input-hint">{nickname.length}/20</span>
          </div>

          <div className="input-group">
            <label htmlFor="roomCode">Room Code (Optional)</label>
            <input
  id="roomCode"
  type="text"
  inputMode="numeric"
  pattern="\d*"
  placeholder="Enter 5-digit code to join"
  value={roomCode}
  onChange={(e) => {
    // Only allow numeric input, max 5 digits
    const value = e.target.value.replace(/\D/g, '').slice(0, 5);
    setRoomCode(value);
  }}
  onKeyPress={handleKeyPress}
  maxLength={5}
  disabled={loading}
/>

            <span className="input-hint">Leave empty to create new room</span>
          </div>

          <div className="button-group">
            <button
              className="btn btn-primary"
              onClick={handleCreateRoom}
              disabled={loading || !nickname.trim()}
            >
              {loading ? '⏳ Creating...' : '✨ Create Room'}
            </button>

            <button
              className="btn btn-secondary"
              onClick={handleJoinRoom}
              disabled={loading || !nickname.trim() || !roomCode.trim()}
            >
              {loading ? '⏳ Joining...' : '🚪 Join Room'}
            </button>
          </div>
        </div>

        <div className="home-footer">
          <p className="info-text">
            💡 No login required • Real-time messaging • Code sharing
          </p>
        </div>
      </div>
    </div>
  );
}

export default HomePage;
