import { useState, useEffect, useRef } from 'react';
import { io } from 'socket.io-client';
import ChatWindow from './ChatWindow';
import InputBox from './InputBox';
import './RoomPage.css';

const SOCKET_URL = 'http://localhost:3000';

/**
 * RoomPage Component
 * Main room interface with real-time chat
 */
function RoomPage({ roomCode, nickname, onLeaveRoom }) {
  const [messages, setMessages] = useState([]);
  const [userCount, setUserCount] = useState(1);
  const [connectionStatus, setConnectionStatus] = useState('connecting'); // 'connecting' | 'connected' | 'error'
  const [error, setError] = useState('');
  
  const socketRef = useRef(null);
  const hasJoinedRef = useRef(false);

  /**
   * Initialize socket connection
   */
  useEffect(() => {
    // Create socket connection
    socketRef.current = io(SOCKET_URL, {
      transports: ['websocket', 'polling']
    });

    const socket = socketRef.current;

    // Connection established
    socket.on('connect', () => {
      console.log('[Connected] Socket ID:', socket.id);
      setConnectionStatus('connected');

      // Join room (only once)
      if (!hasJoinedRef.current) {
        hasJoinedRef.current = true;
        
        socket.emit('joinRoom', { roomCode, nickname }, (response) => {
          if (response.success) {
            console.log('[Joined] Room:', roomCode);
            setUserCount(response.roomInfo.userCount);
            
            // Add system message
            setMessages([{
              type: 'system',
              content: `Welcome to room ${roomCode}! You joined as ${nickname}.`,
              timestamp: Date.now()
            }]);
          } else {
            console.error('[Join Error]', response.error);
            setError(response.error);
            setConnectionStatus('error');
          }
        });
      }
    });

    // Connection error
    socket.on('connect_error', (err) => {
      console.error('[Connection Error]', err);
      setConnectionStatus('error');
      setError('Failed to connect to server. Please check if the server is running.');
    });

    // Receive new messages
    socket.on('newMessage', (message) => {
      console.log('[New Message]', message);
      setMessages((prev) => [...prev, message]);
    });

    // User joined notification
    socket.on('userJoined', (data) => {
      console.log('[User Joined]', data);
      setUserCount(data.userCount);
      setMessages((prev) => [...prev, {
        type: 'system',
        content: `${data.nickname} joined the room`,
        timestamp: data.timestamp
      }]);
    });

    // User left notification
    socket.on('userLeft', (data) => {
      console.log('[User Left]', data);
      setUserCount(data.userCount);
      setMessages((prev) => [...prev, {
        type: 'system',
        content: `${data.nickname} left the room`,
        timestamp: data.timestamp
      }]);
    });

    // Cleanup on unmount
    return () => {
      console.log('[Disconnecting] Socket');
      socket.disconnect();
    };
  }, [roomCode, nickname]);

  /**
   * Handle sending a message
   */
  const handleSendMessage = (type, content) => {
    if (!socketRef.current || connectionStatus !== 'connected') {
      console.error('[Send Error] Not connected');
      return;
    }

    socketRef.current.emit('sendMessage', { type, content }, (response) => {
      if (!response.success) {
        console.error('[Send Error]', response.error);
        alert(`Failed to send message: ${response.error}`);
      }
    });
  };

  /**
   * Handle leaving the room
   */
  const handleLeave = () => {
    if (socketRef.current) {
      socketRef.current.emit('leaveRoom', () => {
        console.log('[Left] Room');
        onLeaveRoom();
      });
    } else {
      onLeaveRoom();
    }
  };

  /**
   * Copy room code to clipboard
   */
  const handleCopyRoomCode = () => {
    navigator.clipboard.writeText(roomCode);
    alert(`Room code ${roomCode} copied to clipboard!`);
  };

  return (
    <div className="room-page">
      <div className="room-container">
        {/* Header */}
        <div className="room-header">
          <div className="room-info">
            <div className="room-code-section">
              <span className="room-label">Room Code:</span>
              <button className="room-code" onClick={handleCopyRoomCode}>
                {roomCode} 📋
              </button>
            </div>
            <div className="user-count">
              <span className="user-icon">👥</span>
              <span>{userCount} {userCount === 1 ? 'user' : 'users'}</span>
            </div>
          </div>
          <button className="leave-btn" onClick={handleLeave}>
            ← Leave Room
          </button>
        </div>

        {/* Connection Status */}
        {connectionStatus === 'connecting' && (
          <div className="status-banner status-connecting">
            ⏳ Connecting to server...
          </div>
        )}

        {connectionStatus === 'error' && (
          <div className="status-banner status-error">
            ⚠️ {error || 'Connection error'}
          </div>
        )}

        {/* Chat Area */}
        <div className="room-content">
          <ChatWindow messages={messages} currentNickname={nickname} />
          
          <InputBox 
            onSendMessage={handleSendMessage}
            disabled={connectionStatus !== 'connected'}
          />
        </div>
      </div>
    </div>
  );
}

export default RoomPage;
