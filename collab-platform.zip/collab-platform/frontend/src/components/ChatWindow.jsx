import { useEffect, useRef } from 'react';
import Message from './Message';
import './ChatWindow.css';

/**
 * ChatWindow Component
 * Displays the message history with auto-scroll
 */
function ChatWindow({ messages, currentNickname }) {
  const messagesEndRef = useRef(null);
  const chatContainerRef = useRef(null);

  /**
   * Auto-scroll to bottom when new messages arrive
   */
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  return (
    <div className="chat-window" ref={chatContainerRef}>
      <div className="messages-container">
        {messages.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">💬</div>
            <p>No messages yet. Start the conversation!</p>
          </div>
        ) : (
          messages.map((message, index) => (
            <Message 
              key={index}
              message={message}
              isOwnMessage={message.nickname === currentNickname}
            />
          ))
        )}
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
}

export default ChatWindow;
