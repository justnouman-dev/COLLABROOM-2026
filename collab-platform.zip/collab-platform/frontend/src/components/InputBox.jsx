import { useState, useRef } from 'react';
import './InputBox.css';

/**
 * InputBox Component
 * Handles message input with text/code detection
 */
function InputBox({ onSendMessage, disabled }) {
  const [input, setInput] = useState('');
  const [isCodeMode, setIsCodeMode] = useState(false);
  const textareaRef = useRef(null);

  /**
   * Handle input change and detect /code prefix
   */
  const handleInputChange = (e) => {
    const value = e.target.value;
    setInput(value);

    // Detect /code prefix
    if (value.startsWith('/code ')) {
      setIsCodeMode(true);
    } else {
      setIsCodeMode(false);
    }
  };

  /**
   * Handle sending message
   */
  const handleSend = () => {
    if (!input.trim() || disabled) return;

    let type = 'text';
    let content = input;

    // Check if it's a code message
    if (input.startsWith('/code ')) {
      type = 'code';
      content = input.substring(6); // Remove "/code " prefix
    }

    // Validate length
    const maxLength = type === 'text' ? 1000 : 15000;
    if (content.length > maxLength) {
      alert(`Message too long! Maximum ${maxLength} characters for ${type} messages.`);
      return;
    }

    // Send message
    onSendMessage(type, content);

    // Clear input
    setInput('');
    setIsCodeMode(false);

    // Reset textarea height
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  /**
   * Handle Enter key (send message)
   * Shift+Enter for new line
   */
  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  /**
   * Auto-resize textarea
   */
  const handleTextareaResize = (e) => {
    const textarea = e.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 150) + 'px';
  };

  // Calculate character count and limit
  const maxLength = isCodeMode ? 15000 : 1000;
  const charCount = isCodeMode ? input.substring(6).length : input.length;
  const isOverLimit = charCount > maxLength;

  return (
    <div className="input-box">
      {isCodeMode && (
        <div className="code-mode-indicator">
          💻 Code Mode - Type your code snippet
        </div>
      )}
      
      <div className="input-container">
        <textarea
          ref={textareaRef}
          className={`message-input ${isCodeMode ? 'code-input' : ''}`}
          placeholder={isCodeMode ? "Type your code..." : "Type a message... (Use /code for code snippets)"}
          value={input}
          onChange={(e) => {
            handleInputChange(e);
            handleTextareaResize(e);
          }}
          onKeyDown={handleKeyDown}
          disabled={disabled}
          rows={1}
        />
        
        <button 
          className="send-btn"
          onClick={handleSend}
          disabled={disabled || !input.trim() || isOverLimit}
        >
          {isCodeMode ? '📝' : '📤'}
        </button>
      </div>

      <div className="input-footer">
        <span className={`char-count ${isOverLimit ? 'over-limit' : ''}`}>
          {charCount} / {maxLength}
        </span>
        <span className="hint">
          💡 Press Enter to send, Shift+Enter for new line
        </span>
      </div>
    </div>
  );
}

export default InputBox;
