import { useState } from 'react';
import './Message.css';

/**
 * Message Component
 * Renders individual messages (text, code, or system)
 */
function Message({ message, isOwnMessage }) {
  const { type, nickname, content, timestamp } = message;
  
  // State for copy button feedback
  const [copied, setCopied] = useState(false);

  /**
   * Format timestamp to readable time
   */
  const formatTime = (ts) => {
    const date = new Date(ts);
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  /**
   * Handle copying code to clipboard
   */
  const handleCopyCode = async (code) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      
      // Reset after 1.5 seconds
      setTimeout(() => {
        setCopied(false);
      }, 1500);
    } catch (err) {
      console.error('Failed to copy code:', err);
      // Fallback for older browsers
      fallbackCopyCode(code);
    }
  };

  /**
   * Fallback copy method for older browsers
   */
  const fallbackCopyCode = (code) => {
    const textarea = document.createElement('textarea');
    textarea.value = code;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    
    try {
      document.execCommand('copy');
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch (err) {
      console.error('Fallback copy failed:', err);
    }
    
    document.body.removeChild(textarea);
  };

  /**
   * Render system message (user joined/left)
   */
  if (type === 'system') {
    return (
      <div className="message message-system">
        <span className="system-content">{content}</span>
        <span className="message-time">{formatTime(timestamp)}</span>
      </div>
    );
  }

  /**
   * Render text or code message
   */
  return (
    <div className={`message message-${type} ${isOwnMessage ? 'message-own' : 'message-other'}`}>
      <div className="message-header">
        <span className="message-nickname">{nickname}</span>
        <span className="message-time">{formatTime(timestamp)}</span>
      </div>
      
      <div className="message-content">
        {type === 'code' ? (
          <div className="code-container">
            <button
              className="code-copy-btn"
              onClick={() => handleCopyCode(content)}
              aria-label="Copy code"
            >
              {copied ? '✓ Copied!' : 'Copy'}
            </button>
            <pre className="code-block">
              <code>{content}</code>
            </pre>
          </div>
        ) : (
          <p className="text-content">{content}</p>
        )}
      </div>
    </div>
  );
}

export default Message;
