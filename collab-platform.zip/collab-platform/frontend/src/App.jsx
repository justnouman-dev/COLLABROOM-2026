import { useState } from 'react';
import HomePage from './components/HomePage';
import RoomPage from './components/RoomPage';
import './App.css';

/**
 * Main App Component
 * Manages routing between HomePage and RoomPage
 */
function App() {
  const [currentPage, setCurrentPage] = useState('home'); // 'home' | 'room'
  const [roomData, setRoomData] = useState({
    roomCode: '',
    nickname: ''
  });

  /**
   * Handle joining a room
   * @param {string} roomCode 
   * @param {string} nickname 
   */
  const handleJoinRoom = (roomCode, nickname) => {
    setRoomData({ roomCode, nickname });
    setCurrentPage('room');
  };

  /**
   * Handle leaving a room (back to home)
   */
  const handleLeaveRoom = () => {
    setRoomData({ roomCode: '', nickname: '' });
    setCurrentPage('home');
  };

  return (
    <div className="app">
      {currentPage === 'home' ? (
        <HomePage onJoinRoom={handleJoinRoom} />
      ) : (
        <RoomPage 
          roomCode={roomData.roomCode}
          nickname={roomData.nickname}
          onLeaveRoom={handleLeaveRoom}
        />
      )}
    </div>
  );
}

export default App;
