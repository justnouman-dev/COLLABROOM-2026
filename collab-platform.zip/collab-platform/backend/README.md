# Collab Platform Backend

Anonymous real-time collaboration platform backend with Express and Socket.io.

## Features

- **In-memory room management** (no database)
- **Socket.io real-time communication**
- **Room capacity limits** (60 users per room)
- **Message validation** (text: 1000 chars, code: 15000 chars)
- **Rate limiting** (1 message per second per user)
- **Nickname uniqueness** per room

## Installation

```bash
npm install
```

## Run

```bash
# Development (with nodemon)
npm run dev

# Production
npm start
```

Server runs on port 3000 by default.

## API Endpoints

### HTTP
- `GET /health` - Server health check

### Socket.io Events

**Client → Server:**
- `joinRoom` - Join a room with nickname
- `sendMessage` - Send text or code message
- `leaveRoom` - Leave current room
- `disconnect` - Automatic cleanup

**Server → Client:**
- `newMessage` - Broadcast message to room
- `userJoined` - User joined notification
- `userLeft` - User left notification

## Project Structure

```
backend/
├── server.js          # Main server and Socket.io logic
├── roomManager.js     # In-memory room state management
├── validators.js      # Input validation utilities
└── package.json
```

## Environment Variables

- `PORT` - Server port (default: 3000)
- `NODE_ENV` - Environment (development/production)
