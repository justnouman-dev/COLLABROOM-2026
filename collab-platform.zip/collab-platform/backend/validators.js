/**
 * Validation utilities for user inputs
 */

const ROOM_CODE_PATTERN = /^\d{5}$/; // Exactly 5 digits
const MAX_NICKNAME_LENGTH = 20;
const MAX_TEXT_MESSAGE_LENGTH = 1000;
const MAX_CODE_MESSAGE_LENGTH = 15000;

/**
 * Validate room code format
 * @param {string} roomCode 
 * @returns {object} { valid: boolean, error?: string }
 */
function validateRoomCode(roomCode) {
  if (!roomCode || typeof roomCode !== 'string') {
    return { valid: false, error: 'Room code is required' };
  }

  if (!ROOM_CODE_PATTERN.test(roomCode)) {
    return { valid: false, error: 'Room code must be exactly 5 digits' };

  }

  return { valid: true };
}

/**
 * Validate nickname
 * @param {string} nickname 
 * @returns {object} { valid: boolean, error?: string }
 */
function validateNickname(nickname) {
  if (!nickname || typeof nickname !== 'string') {
    return { valid: false, error: 'Nickname is required' };
  }

  const trimmed = nickname.trim();

  if (trimmed.length === 0) {
    return { valid: false, error: 'Nickname cannot be empty' };
  }

  if (trimmed.length > MAX_NICKNAME_LENGTH) {
    return { valid: false, error: `Nickname must be ${MAX_NICKNAME_LENGTH} characters or less` };
  }

  return { valid: true };
}

/**
 * Validate message content
 * @param {string} type - "text" or "code"
 * @param {string} content 
 * @returns {object} { valid: boolean, error?: string }
 */
function validateMessage(type, content) {
  if (!type || !['text', 'code'].includes(type)) {
    return { valid: false, error: 'Invalid message type' };
  }

  if (typeof content !== 'string') {
    return { valid: false, error: 'Message content must be a string' };
  }

  if (content.trim().length === 0) {
    return { valid: false, error: 'Message cannot be empty' };
  }

  const maxLength = type === 'text' ? MAX_TEXT_MESSAGE_LENGTH : MAX_CODE_MESSAGE_LENGTH;

  if (content.length > maxLength) {
    return { 
      valid: false, 
      error: `${type === 'text' ? 'Text' : 'Code'} message exceeds ${maxLength} characters` 
    };
  }

  return { valid: true };
}

module.exports = {
  validateRoomCode,
  validateNickname,
  validateMessage
};
