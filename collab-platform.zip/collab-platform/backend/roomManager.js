/**
 * RoomManager - Manages in-memory room state
 *
 * Room structure:
 * {
 *   [roomCode]: {
 *     users: Map<socketId, nickname>,
 *     createdAt: timestamp
 *   }
 * }
 */

class RoomManager {
  constructor() {
    // In-memory storage: Map<roomCode, { users: Map, createdAt: number }>
    this.rooms = new Map();
    this.MAX_USERS_PER_ROOM = 60;
  }

  /**
   * Generate a random 5-digit numeric room code with leading zeros
   * Example: "00482", "91234"
   * @returns {string}
   */
  generateRoomCode() {
    const randomNum = Math.floor(Math.random() * 100000);
    return randomNum.toString().padStart(5, "0");
  }

  /**
   * Generate a unique room code that doesn't already exist
   * @returns {string}
   */
  generateUniqueRoomCode() {
    let code;
    let attempts = 0;
    const MAX_ATTEMPTS = 100;

    do {
      code = this.generateRoomCode();
      attempts++;

      if (attempts >= MAX_ATTEMPTS) {
        throw new Error(
          "Failed to generate unique room code after 100 attempts"
        );
      }
    } while (this.roomExists(code));

    return code;
  }

  /**
   * Create a new room or return existing one
   * @param {string} roomCode
   * @returns {object}
   */
  getOrCreateRoom(roomCode) {
    if (!this.rooms.has(roomCode)) {
      this.rooms.set(roomCode, {
        users: new Map(),
        createdAt: Date.now(),
      });
      console.log(`[ROOM] Created new room: ${roomCode}`);
    }

    return this.rooms.get(roomCode);
  }

  /**
   * Check if a user can join a room
   * @param {string} roomCode
   * @returns {boolean}
   */
  canJoinRoom(roomCode) {
    const room = this.rooms.get(roomCode);
    if (!room) return true; // New room
    return room.users.size < this.MAX_USERS_PER_ROOM;
  }

  /**
   * Add user to a room
   * @param {string} roomCode
   * @param {string} socketId
   * @param {string} nickname
   * @returns {{ success: boolean, error?: string }}
   */
  addUserToRoom(roomCode, socketId, nickname) {
    const room = this.getOrCreateRoom(roomCode);

    if (room.users.size >= this.MAX_USERS_PER_ROOM) {
      return { success: false, error: "Room is full" };
    }

    const existingNicknames = Array.from(room.users.values());
    if (existingNicknames.includes(nickname)) {
      return {
        success: false,
        error: "Nickname already taken in this room",
      };
    }

    room.users.set(socketId, nickname);
    return { success: true };
  }

  /**
   * Remove user from room
   * @param {string} roomCode
   * @param {string} socketId
   */
  removeUserFromRoom(roomCode, socketId) {
    const room = this.rooms.get(roomCode);
    if (!room) return;

    room.users.delete(socketId);

    // Delete empty room
    if (room.users.size === 0) {
      this.rooms.delete(roomCode);
      console.log(`[ROOM] Deleted empty room: ${roomCode}`);
    }
  }

  /**
   * Get room info
   * @param {string} roomCode
   * @returns {{ userCount: number, users: string[] } | null}
   */
  getRoomInfo(roomCode) {
    const room = this.rooms.get(roomCode);
    if (!room) return null;

    return {
      userCount: room.users.size,
      users: Array.from(room.users.values()),
    };
  }

  /**
   * Get total active rooms
   * @returns {number}
   */
  getActiveRoomsCount() {
    return this.rooms.size;
  }

  /**
   * Get total users across all rooms
   * @returns {number}
   */
  getTotalUsersCount() {
    let total = 0;
    for (const room of this.rooms.values()) {
      total += room.users.size;
    }
    return total;
  }

  /**
   * Check if room exists
   * @param {string} roomCode
   * @returns {boolean}
   */
  roomExists(roomCode) {
    return this.rooms.has(roomCode);
  }
}

module.exports = RoomManager;
