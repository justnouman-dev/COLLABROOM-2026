const express = require('express');
const { createServer } = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const RoomManager = require('./roomManager');
const { validateMessage, validateNickname, validateRoomCode } = require('./validators');

const app = express();
const httpServer = createServer(app);

// Configure CORS for Express and Socket.io
app.use(cors());

const io = new Server(httpServer, {
  cors: {
    origin: "http://localhost:5173", // Vite default port
    methods: ["GET", "POST"]
  }
});

// Initialize room manager
const roomManager = new RoomManager();

// Middleware
app.use(express.json());

// Basic health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok',
    activeRooms: roomManager.getActiveRoomsCount(),
    totalUsers: roomManager.getTotalUsersCount()
  });
});

// Socket.io connection handling
io.on('connection', (socket) => {
  console.log(`[CONNECTION] Socket connected: ${socket.id}`);
  
  // Store user info on socket
  socket.userData = {
    nickname: null,
    roomCode: null,
    lastMessageTime: 0
  };

  /**
   * Handle user joining a room
   * Payload: { roomCode: string, nickname: string }
   */
  socket.on('joinRoom', (data, callback) => {
    try {
      const { roomCode, nickname } = data;

      // Validate inputs
      const nicknameValidation = validateNickname(nickname);
      if (!nicknameValidation.valid) {
        return callback({ success: false, error: nicknameValidation.error });
      }

      const roomCodeValidation = validateRoomCode(roomCode);
      if (!roomCodeValidation.valid) {
        return callback({ success: false, error: roomCodeValidation.error });
      }

      // Check room capacity
      if (!roomManager.canJoinRoom(roomCode)) {
        return callback({ success: false, error: 'Room is full (max 60 users)' });
      }

      // Add user to room
      const result = roomManager.addUserToRoom(roomCode, socket.id, nickname);
      if (!result.success) {
        return callback({ success: false, error: result.error });
      }

      // Store user data
      socket.userData.nickname = nickname;
      socket.userData.roomCode = roomCode;

      // Join socket.io room
      socket.join(roomCode);

      // Get room info
      const roomInfo = roomManager.getRoomInfo(roomCode);

      // Notify others in the room
      socket.to(roomCode).emit('userJoined', {
        nickname,
        userCount: roomInfo.userCount,
        timestamp: Date.now()
      });

      console.log(`[JOIN] ${nickname} joined room ${roomCode} (${roomInfo.userCount} users)`);

      // Send success response with room info
      callback({
        success: true,
        roomInfo: {
          roomCode,
          userCount: roomInfo.userCount,
          users: roomInfo.users
        }
      });

    } catch (error) {
      console.error('[JOIN ERROR]', error);
      callback({ success: false, error: 'Failed to join room' });
    }
  });

  /**
   * Handle sending messages
   * Payload: { type: "text" | "code", content: string }
   */
  socket.on('sendMessage', (data, callback) => {
    try {
      const { type, content } = data;
      const { nickname, roomCode, lastMessageTime } = socket.userData;

      // Check if user is in a room
      if (!roomCode || !nickname) {
        return callback({ success: false, error: 'Not in a room' });
      }

      // Rate limiting: 1 message per second
      const now = Date.now();
      if (now - lastMessageTime < 1000) {
        return callback({ success: false, error: 'Rate limit: 1 message per second' });
      }

      // Validate message
      const validation = validateMessage(type, content);
      if (!validation.valid) {
        return callback({ success: false, error: validation.error });
      }

      // Update last message time
      socket.userData.lastMessageTime = now;

      // Create message object
      const message = {
        type,
        nickname,
        content,
        timestamp: now
      };

      // Broadcast to all users in the room (including sender)
      io.to(roomCode).emit('newMessage', message);

      console.log(`[MESSAGE] ${nickname} in ${roomCode}: ${type} (${content.length} chars)`);

      callback({ success: true });

    } catch (error) {
      console.error('[MESSAGE ERROR]', error);
      callback({ success: false, error: 'Failed to send message' });
    }
  });

  /**
   * Handle user disconnect
   */
  socket.on('disconnect', () => {
    const { nickname, roomCode } = socket.userData;

    if (roomCode && nickname) {
      // Remove user from room
      roomManager.removeUserFromRoom(roomCode, socket.id);

      // Get updated room info
      const roomInfo = roomManager.getRoomInfo(roomCode);

      if (roomInfo) {
        // Notify others
        socket.to(roomCode).emit('userLeft', {
          nickname,
          userCount: roomInfo.userCount,
          timestamp: Date.now()
        });

        console.log(`[LEAVE] ${nickname} left room ${roomCode} (${roomInfo.userCount} users remaining)`);
      } else {
        console.log(`[LEAVE] ${nickname} left room ${roomCode} (room closed)`);
      }
    }

    console.log(`[DISCONNECT] Socket disconnected: ${socket.id}`);
  });

  /**
   * Handle explicit leave room
   */
  socket.on('leaveRoom', (callback) => {
    const { nickname, roomCode } = socket.userData;

    if (roomCode) {
      socket.leave(roomCode);
      
      if (nickname) {
        roomManager.removeUserFromRoom(roomCode, socket.id);
        const roomInfo = roomManager.getRoomInfo(roomCode);

        if (roomInfo) {
          socket.to(roomCode).emit('userLeft', {
            nickname,
            userCount: roomInfo.userCount,
            timestamp: Date.now()
          });
        }
      }

      socket.userData.roomCode = null;
      socket.userData.nickname = null;
      
      console.log(`[LEAVE] ${nickname} left room ${roomCode}`);
    }

    if (callback) callback({ success: true });
  });
});

const PORT = process.env.PORT || 3000;

httpServer.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════╗
║   Collab Platform Server Running       ║
║   Port: ${PORT}                            ║
║   Environment: ${process.env.NODE_ENV || 'development'}              ║
╚════════════════════════════════════════╝
  `);
});
